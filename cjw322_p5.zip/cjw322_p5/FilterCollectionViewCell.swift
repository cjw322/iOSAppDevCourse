//
//  FilterCollectionViewCell.swift
//  cjw322_p5
//
//  Created by Cora Wu on 11/7/18.
//  Copyright © 2018 Cora Wu. All rights reserved.
//

import UIKit

class FilterCollectionViewCell: UICollectionViewCell {
    
    var filterLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        filterLabel = UILabel(frame: .zero)
        filterLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(filterLabel)
    }
    
    override func updateConstraints() {
        NSLayoutConstraint.activate([
            filterLabel.topAnchor.constraint(equalTo: contentView.topAnchor),
            filterLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            filterLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            filterLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
            ])
        super.updateConstraints()
    }
    
    func configure(with filter: String) {
//        filterLabel = UILabel()
        filterLabel.text = filter
        filterLabel.backgroundColor = .black
        filterLabel.textColor = .white
        filterLabel.textAlignment = .center
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
