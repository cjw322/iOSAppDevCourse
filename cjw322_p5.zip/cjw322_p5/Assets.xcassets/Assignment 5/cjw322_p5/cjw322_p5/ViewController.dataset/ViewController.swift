//
//  ViewController.swift
//  cjw322_p5
//
//  Created by Cora Wu on 11/5/18.
//  Copyright © 2018 Cora Wu. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    var restaurantArray: [Restaurant]!
    var collectionView: UICollectionView!
    
    let photoCellReuseIdentifier = "photoCellReuseIdentifier"
    let padding: CGFloat = 8

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let McDonalds = Restaurant(restaurantName: "McDonalds", cost: "$")
        let Chipotle = Restaurant(restaurantName: "Chipotle", cost: "$")
        let HaiDiLao = Restaurant(restaurantName: "HaiDiLao", cost: "$$$")
        let MiPiace = Restaurant(restaurantName: "MiPiace", cost: "$$$")
        let XiaoFeiYang = Restaurant(restaurantName: "XiaoFeiYang", cost: "$$")
        let Dish = Restaurant(restaurantName: "Dish", cost: "$$")
        let DinTaiFung = Restaurant(restaurantName: "DinTaiFung", cost: "$$$")
        let StarCafe = Restaurant(restaurantName: "StarCafe", cost: "$$")
        let Tatsunoya = Restaurant(restaurantName: "Tatsunoya", cost: "$$")
        let PaneraBread = Restaurant(restaurantName: "PaneraBread", cost: "$$")
        
        restaurantArray = [McDonalds, Chipotle, HaiDiLao, MiPiace, XiaoFeiYang, Dish, DinTaiFung, StarCafe, Tatsunoya, PaneraBread]
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumInteritemSpacing = padding
        layout.minimumLineSpacing = padding
        layout.itemSize = CGSize(width: 200, height: 200)
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .white
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(PhotoCollectionViewCell.self, forCellWithReuseIdentifier: photoCellReuseIdentifier)
        view.addSubview(collectionView)
        
        setUpConstraints()
    }
    
    func setUpConstraints() {
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
            ])
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: photoCellReuseIdentifier, for: indexPath) as! PhotoCollectionViewCell
        let restaurant = restaurantArray[indexPath.item]
        
        cell.configure(with: restaurant)
        cell.setNeedsUpdateConstraints()
        // so our subviews and cells actually get a layout
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // number of cells we want
        return restaurantArray.count
    }
    
//    func collectionView(_collectionView: UICollectionViewCell, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        //takes in both width and height
//        let width = (collectionView.frame.width - padding)/2.0
//        //return CGSize(width: width, height: width)
//        return CGSize(width: 1000, height: 1000)
//    }


}

