//
//  Restaurant.swift
//  cjw322_p5
//
//  Created by Cora Wu on 11/5/18.
//  Copyright © 2018 Cora Wu. All rights reserved.
//

import UIKit

class Restaurant {
    
    var restaurantName: String
    var cost: String
    
    init(restaurantName: String, cost: String) {
        self.restaurantName = restaurantName
        self.cost = cost
    }
}
