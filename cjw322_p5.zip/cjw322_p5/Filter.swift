//
//  Filter.swift
//  cjw322_p5
//
//  Created by Cora Wu on 11/5/18.
//  Copyright © 2018 Cora Wu. All rights reserved.
//

import UIKit

//class Filter {
//
//    var cheap: String = "$"
//    var moderate: String = "$$"
//    var expensive: String = "$$$"
//    var allMeals: String = "All Meals"
//    var breakfast: String = "Breakfast"
//    var lunch: String = "Lunch"
//    var dinner: String = "Dinner"
//    var lunchDinner: String = "Lunch, Dinner"
//    var breakfastLunch: String = "Breakfast, Lunch"
//    var breakfastDinner: String = "Breakfast, Dinner"
//
//    init(cheap: String, moderate: String, expensive: String, allMeals: String, breakfast: String, lunch: String, dinner: String, lunchDinner: String, breakfastLunch: String, breakfastDinner: String) {
//        self.cheap = cheap
//        self.moderate = moderate
//        self.expensive = expensive
//        self.allMeals = allMeals
//        self.breakfast = breakfast
//        self.lunch = lunch
//        self.dinner = dinner
//        self.breakfastLunch = breakfastLunch
//        self.breakfastDinner = breakfastDinner
//        self.lunchDinner = lunchDinner
//    }
//}

// what if i made the class contain strings
// and still made the photocollection cell buttons
// if pressed, change colors & delete restaurants from array based on their qualities
// if restaurant.cost !=  && restaurant.mealTime != "Lunch, Dinner", delete from array
