//
//  ViewController.swift
//  cjw322_p5
//
//  Created by Cora Wu on 11/5/18.
//  Copyright © 2018 Cora Wu. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    var restaurantArray: [Restaurant]!
    var filterArray: [String]!
    var restaurantCollectionView: UICollectionView!
    var filterCollectionView: UICollectionView!
    var filterTitleLabel: UILabel!
    var restaurantTitleLabel: UILabel!
    
    let photoCellReuseIdentifier = "photoCellReuseIdentifier"
    let filterCellReuseIdentifier = "filterCellReuseIdentifier"
    let padding: CGFloat = 8

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        view.backgroundColor = .white
        title = "Random Restaurants"
        
        let McDonalds = Restaurant(restaurantName: "McDonalds", cost: "$", mealTime: "All Meals", waitTime: "short wait", reservations: "no")
        let Chipotle = Restaurant(restaurantName: "Chipotle", cost: "$", mealTime: "All Meals", waitTime: "short wait", reservations: "no")
        let HaiDiLao = Restaurant(restaurantName: "HaiDiLao", cost: "$$$", mealTime: "Lunch, Dinner", waitTime: "long wait", reservations: "yes")
        let MiPiace = Restaurant(restaurantName: "MiPiace", cost: "$$$", mealTime: "Dinner", waitTime: "long wait", reservations: "yes")
        let XiaoFeiYang = Restaurant(restaurantName: "XiaoFeiYang", cost: "$$", mealTime: "All Meals", waitTime: "medium wait", reservations: "yes")
        let Dish = Restaurant(restaurantName: "Dish", cost: "$$", mealTime: "All Meals", waitTime: "medium wait", reservations: "yes")
        let DinTaiFung = Restaurant(restaurantName: "DinTaiFung", cost: "$$$", mealTime: "All Meals", waitTime: "long wait", reservations: "yes")
        let StarCafe = Restaurant(restaurantName: "StarCafe", cost: "$$", mealTime: "All Meals", waitTime: "medium wait", reservations: "yes")
        let Tatsunoya = Restaurant(restaurantName: "Tatsunoya", cost: "$$", mealTime: "All Meals", waitTime: "medium wait", reservations: "no")
        let PaneraBread = Restaurant(restaurantName: "PaneraBread", cost: "$$", mealTime: "All Meals", waitTime: "short wait", reservations: "no")
        
        restaurantArray = [McDonalds, Chipotle, HaiDiLao, MiPiace, XiaoFeiYang, Dish, DinTaiFung, StarCafe, Tatsunoya, PaneraBread]
        
        filterArray = ["cheap", "moderate", "expensive", "breakfast", "lunch", "dinner", "short wait", "medium wait", "long wait", "reservations", "no reservations"]
        
        filterTitleLabel = UILabel()
        filterTitleLabel.translatesAutoresizingMaskIntoConstraints = false
        filterTitleLabel.text = "FILTERS"
        view.addSubview(filterTitleLabel)
        
        restaurantTitleLabel = UILabel()
        restaurantTitleLabel.translatesAutoresizingMaskIntoConstraints = false
        restaurantTitleLabel.text = "RESTAURANTS"
        view.addSubview(restaurantTitleLabel)
        
        let restaurantLayout = UICollectionViewFlowLayout()
        restaurantLayout.scrollDirection = .vertical
        restaurantLayout.minimumInteritemSpacing = padding
        restaurantLayout.minimumLineSpacing = padding
        restaurantLayout.itemSize = CGSize(width: 200, height: 200)
        restaurantCollectionView = UICollectionView(frame: .zero, collectionViewLayout: restaurantLayout)
        restaurantCollectionView.translatesAutoresizingMaskIntoConstraints = false
        restaurantCollectionView.backgroundColor = .white
        restaurantCollectionView.delegate = self
        restaurantCollectionView.dataSource = self
        restaurantCollectionView.register(PhotoCollectionViewCell.self, forCellWithReuseIdentifier: photoCellReuseIdentifier)
        view.addSubview(restaurantCollectionView)
        
        let filterLayout = UICollectionViewFlowLayout()
        filterLayout.scrollDirection = .horizontal
        filterLayout.minimumInteritemSpacing = padding*0.5
        filterLayout.minimumLineSpacing = padding*0.5
        filterLayout.itemSize = CGSize(width: 130, height: 30)
        filterCollectionView = UICollectionView(frame: .zero, collectionViewLayout: filterLayout)
        filterCollectionView.translatesAutoresizingMaskIntoConstraints = false
        filterCollectionView.backgroundColor = .white
        filterCollectionView.delegate = self
        filterCollectionView.dataSource = self
        filterCollectionView.allowsMultipleSelection = true
        filterCollectionView.register(FilterCollectionViewCell.self, forCellWithReuseIdentifier: filterCellReuseIdentifier)
        view.addSubview(filterCollectionView)
        
        setUpConstraints()
    }
    
    func setUpConstraints() {
        NSLayoutConstraint.activate([
            filterTitleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            filterTitleLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            filterTitleLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            filterTitleLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
            ])
        NSLayoutConstraint.activate([
            filterCollectionView.topAnchor.constraint(equalTo: filterTitleLabel.bottomAnchor),
            filterCollectionView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            filterCollectionView.bottomAnchor.constraint(equalTo: filterTitleLabel.bottomAnchor, constant: 60),
            filterCollectionView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
            ])
        NSLayoutConstraint.activate([
            restaurantTitleLabel.topAnchor.constraint(equalTo: filterCollectionView.bottomAnchor, constant: 10),
            restaurantTitleLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            restaurantTitleLabel.bottomAnchor.constraint(equalTo: filterCollectionView.bottomAnchor, constant: 60),
            restaurantTitleLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
            ])
        NSLayoutConstraint.activate([
            restaurantCollectionView.topAnchor.constraint(equalTo: restaurantTitleLabel.bottomAnchor, constant: 8),
            restaurantCollectionView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            restaurantCollectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            restaurantCollectionView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
            ])
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == self.restaurantCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: photoCellReuseIdentifier, for: indexPath) as! PhotoCollectionViewCell
            let restaurant = restaurantArray[indexPath.item]
            
            cell.configure(with: restaurant)
            cell.setNeedsUpdateConstraints()
            // so our subviews and cells actually get a layout
            return cell
        }
        else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: filterCellReuseIdentifier, for: indexPath) as! FilterCollectionViewCell
            let filter = filterArray[indexPath.item]
            
            cell.configure(with: filter)
            cell.setNeedsUpdateConstraints()
            // so our subviews and cells actually get a layout
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // number of cells we want
        if collectionView == self.restaurantCollectionView {
            return restaurantArray.count
        }
        else {
            return filterArray.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        if collectionView == self.filterCollectionView {
            switch indexPath.item {
            case 0:
                removeItems(filterType: "cost", filterFor: "$")
            case 1:
                removeItems(filterType: "cost", filterFor: "$$")
            case 2:
                removeItems(filterType: "cost", filterFor: "$$$")
            case 3:
                removeItems(filterType: "mealTime", filterFor: "breakfast")
            case 4:
                removeItems(filterType: "mealTime", filterFor: "lunch")
            case 5:
                removeItems(filterType: "mealTime", filterFor: "dinner")
            case 6:
                removeItems(filterType: "waitTime", filterFor: "short wait")
            case 7:
                removeItems(filterType: "waitTime", filterFor: "medium wait")
            case 8:
                removeItems(filterType: "waitTime", filterFor: "long wait")
            case 9:
                removeItems(filterType: "reservations", filterFor: "yes")
            case 10:
                removeItems(filterType: "reservations", filterFor: "no")
            default:
                break
            }
        }
    }
    
    func removeItems(filterType: String, filterFor: String) {
//        print(restaurantArray)
//        var restaurantArrayCopy: [Restaurant]
//        restaurantArrayCopy = []
//        for x in restaurantArray {
//            restaurantArrayCopy.append(x)
//        }
//        if filterType == "cost" {
//            for (i, restaurant) in zip(restaurantArray.indices, restaurantArray) {
//                if restaurant.cost != filterFor {
//                    restaurantArrayCopy.remove(at: i)
//                }
//            }
//            print(restaurantArray)
//        }
//        restaurantArray = restaurantArrayCopy
        
        print("removeItems was called")
        
        var timesCalled = 0
        
        while needsUpdating(filterType: filterType, filterFor: filterFor, timesCalled: timesCalled) {
            print("this loop is going")
            if filterType == "cost" && restaurantArray[0].cost != filterFor {
                print("\(restaurantArray[0]) cost: \(restaurantArray[0].cost)")
                restaurantArray.remove(at: 0)
                print(restaurantArray)
            }
            else if filterType == "mealTime" && restaurantArray[0].mealTime != filterFor{
                restaurantArray.remove(at: 0)
            }
            else if filterType == "reservations" && restaurantArray[0].reservations != filterFor{
                restaurantArray.remove(at: 0)
            }
            else if filterType == "waitTime" && restaurantArray[0].waitTime != filterFor {
                restaurantArray.remove(at: 0)
            }
            timesCalled += 1
        }
        
        print("dw not an infinite loop")
        
        restaurantCollectionView.reloadData()
    }
    
    func needsUpdating(filterType: String, filterFor: String, timesCalled: Int) -> Bool {
        
        print("needs updating was called")
        
        for x in restaurantArray[timesCalled...]{
            if filterType == "cost" && x.cost != filterFor{
                return true
            } else if filterType == "mealTime" && x.mealTime != filterFor{
                return true
            } else if filterType == "reservations" && x.reservations != filterFor{
                return true
            } else if filterType == "waitTime" && x.waitTime != filterFor {
                return true
            }
        }
        print("needs updating says no more updates")
        return false
    }
    
//    func collectionView(_collectionView: UICollectionViewCell, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        //takes in both width and height
//        let width = (collectionView.frame.width - padding)/2.0
//        //return CGSize(width: width, height: width)
//        return CGSize(width: 1000, height: 1000)
//    }


}

