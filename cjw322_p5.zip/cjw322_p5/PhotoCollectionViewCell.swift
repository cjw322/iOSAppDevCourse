//
//  PhotoCollectionViewCell.swift
//  cjw322_p5
//
//  Created by Cora Wu on 11/5/18.
//  Copyright © 2018 Cora Wu. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
    var photoImageView: UIImageView!
    var restaurantLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        photoImageView = UIImageView(frame: .zero)
        photoImageView.translatesAutoresizingMaskIntoConstraints = false
        photoImageView.contentMode = .scaleAspectFit
        contentView.addSubview(photoImageView)
        
        restaurantLabel = UILabel()
        restaurantLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(restaurantLabel)
    }
    
    override func updateConstraints() {
        NSLayoutConstraint.activate([
            photoImageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            photoImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            photoImageView.bottomAnchor.constraint(equalTo: contentView.topAnchor, constant: 180),
            photoImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
            ])
        NSLayoutConstraint.activate([
            restaurantLabel.topAnchor.constraint(equalTo: photoImageView.bottomAnchor),
            restaurantLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            restaurantLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            restaurantLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
            ])
        super.updateConstraints()
    }
    
    func configure(with restaurant: Restaurant) {
        photoImageView.image = UIImage(named: restaurant.restaurantName)
        restaurantLabel.text = restaurant.restaurantName
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
