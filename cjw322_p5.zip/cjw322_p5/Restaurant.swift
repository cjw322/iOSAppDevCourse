//
//  Restaurant.swift
//  cjw322_p5
//
//  Created by Cora Wu on 11/5/18.
//  Copyright © 2018 Cora Wu. All rights reserved.
//

import UIKit

class Restaurant {
    
    var restaurantName: String
    var cost: String
    var mealTime: String
    var imageName: String
    var waitTime: String
    var reservations: String
    
    init(restaurantName: String, cost: String, mealTime: String, waitTime: String, reservations: String) {
        self.restaurantName = restaurantName
        self.cost = cost
        self.imageName = restaurantName
        self.mealTime = mealTime
        self.waitTime = waitTime
        self.reservations = reservations
    }
}
