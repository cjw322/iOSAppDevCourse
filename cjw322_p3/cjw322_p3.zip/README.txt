
CHALLENGE #1:
I created a Magical Arena with randomly colored squares.

CHALLENGE #3
I added sliders to the Red Square Arena and the Magical Arena that allow the user to change the size of the squares.
But for some reason (I think it's because the display is meant for touchscreen instead of sliding with a trackpad/mouse?) the sliders work best when you click on them to move them a little first; after that, it's easier to slide. :)