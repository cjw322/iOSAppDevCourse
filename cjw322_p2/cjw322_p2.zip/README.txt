
CHALLENGE #1:
I wasn't able to fully complete this haha
But in this app, the user won't be able to enter empty values into the dictionary; if there's no input under "Item," nothing is added.

CHALLENGE #2:
There's a lock button; when the user taps it, it changes from locked to unlocked. When the app is locked, users cannot add or remove any items.

CHALLENGE #4:
The remove button removes inputted items.